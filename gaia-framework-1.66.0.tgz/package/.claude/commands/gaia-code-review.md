---
name: 'code-review'
description: 'Perform code review. Use when "run code review".'
model: opus
---

IT IS CRITICAL THAT YOU FOLLOW THESE STEPS:

<steps CRITICAL="TRUE">
1. LOAD the FULL {project-root}/_gaia/core/engine/workflow.xml
2. READ its entire contents — this is the CORE OS
3. Pass {project-root}/_gaia/lifecycle/workflows/4-implementation/code-review/workflow.yaml as 'workflow-config'
4. Follow workflow.xml instructions EXACTLY
5. Save outputs after EACH section
</steps>

$ARGUMENTS
