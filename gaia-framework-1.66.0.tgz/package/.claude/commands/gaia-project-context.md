---
name: 'project-context'
description: 'Generate project context for AI. Use when "generate project context".'
model: sonnet
---

IT IS CRITICAL THAT YOU FOLLOW THESE STEPS:

<steps CRITICAL="TRUE">
1. LOAD the FULL {project-root}/_gaia/core/engine/workflow.xml
2. READ its entire contents — this is the CORE OS
3. Pass {project-root}/_gaia/lifecycle/workflows/anytime/generate-project-context/workflow.yaml as 'workflow-config'
4. Follow workflow.xml instructions EXACTLY
5. Save outputs after EACH section
</steps>

$ARGUMENTS
