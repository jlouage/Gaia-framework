---
name: 'test-framework'
description: 'Initialize test framework with appropriate tooling. Use when "setup test framework".'
model: sonnet
---

IT IS CRITICAL THAT YOU FOLLOW THESE STEPS:

<steps CRITICAL="TRUE">
1. LOAD the FULL {project-root}/_gaia/core/engine/workflow.xml
2. READ its entire contents — this is the CORE OS
3. Pass {project-root}/_gaia/testing/workflows/test-framework/workflow.yaml as 'workflow-config'
4. Follow workflow.xml instructions EXACTLY
5. Save outputs after EACH section
</steps>

$ARGUMENTS
